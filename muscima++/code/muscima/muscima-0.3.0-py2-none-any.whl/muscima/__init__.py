from __future__ import print_function, unicode_literals

__version__ = "0.3.0"
__author__ = "Jan Hajic jr."

# This enables importing "from muscima import ..." instead of
# "from muscima.muscima import..."

from muscima import *